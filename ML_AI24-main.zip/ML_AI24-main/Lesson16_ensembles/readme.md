Bias-variance decomposition, бэггинг, бустинг.
